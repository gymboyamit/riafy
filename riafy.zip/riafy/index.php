<?php
session_start();
if(isset($_SESSION['username']))
{

echo '<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}


</style>';

echo'

<div style="margin-top:100px;">

  <Center > 
  <h3><a href="logout.php">Logout</a></h3>
   <h2>Live Stock Search By Company Name </h2>
   <input type="search" placeholder="search stock by company name" 
   style="width:300px;height:50px;border:1px solid black;text-align:center;" 
   onkeyup="fetchdata(this.value)" />
   
   <div id="result" style="margin-top:20px;">
   <mark>
     Note : All Are Dummy Data </mark> </br>
   Note : stored company name on server is ( ACC Limited , Bank of India , Canara Bank , Dena Bank , Excel Infoways Limited)
   
   </div>
   
  </center>
  
 
  


</div>

<script>
 
 function fetchdata(value) {
    if (value.length == 0) {
        document.getElementById("result").innerHTML = "Note : stored company name on server is  ( ACC Limited , Bank of India , Canara Bank , Dena Bank , Excel Infoways Limited)";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "data.php?a=" + value, true);
        xmlhttp.send();
    }
}
 
</script>
';
 
}
else
{
    echo'
    <div style="margin-top:50px;">
    <form method="post" action="user.php" >
    <center>
      <h2>Login Form</h2>
      <input type="text" placeholder="enter username" name="username" required />
      <input type="submit" value="Login" name="submit" />
    </center>
    </form>
    </div>';
}
?>

