<?php
session_start();

if(isset($_POST['submit']))
{
 $username = $_POST['username'];

$conn = mysqli_connect('localhost','db_username','db_password') OR DIE('Unable to connect to database! Please try again later.');
								
    mysqli_select_db($conn, 'db_name');
    
    $sql = "select * from riafyusername where username='$username'";
    
    $result = mysqli_query($conn, $sql);
    
    $row = mysqli_num_rows($result);
    
    if($row==1)
    {
        $_SESSION['username'] = $username ;
        header("location: http://hugdiscountsales.com/riafy");
    }
    else
    {
       echo 'login failed'; 
    }
    
    mysqli_close($conn);
    
}  

else
{
    echo 'page not found go back';
}

?>