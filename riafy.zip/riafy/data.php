<?php

$value = $_GET['a'];

$conn = mysqli_connect('localhost','db_usernam','db_password') OR DIE('Unable to connect to database! Please try again later.');
								
    mysqli_select_db($conn, 'db_name');
    
    $sql = "select * from riafy where company LIKE '%$value%'";
    
    $result = mysqli_query($conn, $sql);
    
    $row = mysqli_num_rows($result);
    
    if($row>=1)
    {
       echo '<div>
              <table>
                <tr>
                 <th>company</th>
                 <th>MarketCap</th>
                 <th>stock</th>
                 <th>StockPE</th>
                 <th>DividendYield</th>
                 <th>ROCE</th>
                 <th>ROE</th>
                 <th>equity</th>
                 <th>EPS</th>
                 <th>Reserves</th>
                 <th>Debt</th>
                </tr>';
      while($re = mysqli_fetch_array($result))
      {
          echo'
               <tr>
                 <td>'.$re['company'].'</td>
                 <td>'.$re['MarketCap'].'</td>
                 <td>'.$re['stock'].'</td>
                 <td>'.$re['StockPE'].'</td>
                 <td>'.$re['DividendYield'].'</td>
                 <td>'.$re['ROCE'].'</td>
                 <td>'.$re['ROE'].'</td>
                 <td>'.$re['equity'].'</td>
                 <td>'.$re['EPS'].'</td>
                 <td>'.$re['Reserves'].'</td>
                 <td>'.$re['Debt'].'</td>
                </tr>
            
          ';
      }
      
      echo ' </table>
           </div>';
      
    }
    
    else
    echo 'No data found (please Search this company names ACC Limited , Bank of India , Canara Bank , Dena Bank , Excel Infoways Limited)';
    
    mysqli_close($conn);

?>